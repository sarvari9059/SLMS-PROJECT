﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SLMSWebAPI.Models
{
    public class AdminLeave
    {
        [Key]
        public int Id { get; set; }
        public int? AdminId { get; set; }
        [ForeignKey("AdminId")]
        public int? LeaveId { get; set; }
        [ForeignKey("LeaveId")]

        [Required]
        public string Status { get; set; }
        [Required]
        public string AdminRemark { get; set; }

        public virtual Admin Admin { get; set; }
        public virtual Leave Leave { get; set; }
       
    }
}
