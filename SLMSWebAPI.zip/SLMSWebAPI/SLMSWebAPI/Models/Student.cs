﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SLMSWebAPI.Models
{
    public class Student
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Fullname { get; set; }

        [Required(ErrorMessage = "enter email id")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required]
        public string Parentphone { get; set; }

        public virtual ICollection<Leave> Leaves { get; set; }
       
    }
}
