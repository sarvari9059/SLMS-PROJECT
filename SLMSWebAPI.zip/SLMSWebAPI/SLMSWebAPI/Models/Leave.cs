﻿using System.Collections.Generic;
using System;
using System.ComponentModel.DataAnnotations;

namespace SLMSWebAPI.Models
{
    public class Leave
    {
        [Key]
        public int Id { get; set; }

        public int? StudentId { get; set; }
        [Required]
        public string Reason { get; set; }
        [Required]
        public string Status { get; set; }
        [Required]
        public DateTime? Todate { get; set; }
        [Required]
        public DateTime? Fromdate { get; set; }
 
        public virtual Student Student { get; set; }
        public virtual ICollection<AdminLeave> AdminLeaves { get; set; }
      
    }
}
