﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SLMSWebAPI.Models;
using SLMSWebAPI.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SLMSWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IAdminRepo Repositories = null;
        public AdminController(IAdminRepo repo)
        {
            Repositories = repo;
        }
        [HttpGet]
        public ActionResult<List<Admin>> Get()
        {
            List<Admin> Admins = Repositories.GetAllAdmins();
            if (Admins.Count > 0)
            {
                return Admins;
            }
            else
            {
                return NotFound();
            }
        }
        [Route("{id:int}")]
        [HttpGet]
        public ActionResult<Admin> Get(int id)
        {
            Admin admin = Repositories.GetAdminById(id);
            if (admin != null)
            {
                return admin;
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        public string Post(Admin admin)
        {
            string Response = Repositories.AddNewAdmin(admin);
            return Response;
        }
        [HttpPut]
        public string Put(Admin admin)
        {
            string Response = Repositories.UpdateAdmin(admin);
            return Response;
        }

        [Route("{id:int}")]
        [HttpDelete]
        public string Delete(int id)
        {
            string Response = Repositories.DeleteAdmin(id);
            return Response;
        }
        [HttpGet]
        [Route("{username}/{password}")]
        public async Task<IActionResult> Login(string username, string password)
        {
            Admin admin = Repositories.AdminGetAdminByName(username, password);
            if (admin != null)
            {
                return Ok(admin);
            }
            else
            {
                return NotFound("admin is invalid");
            }
        }
    }
}
