﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SLMSWebAPI.Models;
using SLMSWebAPI.Repositories;
using System.Collections.Generic;

namespace SLMSWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminLeaveController : ControllerBase
    {
        private readonly IAdminLeaveRepo Repositories = null;
        public AdminLeaveController(IAdminLeaveRepo repo)
        {
            Repositories = repo;
        }
        [HttpGet]
        public ActionResult<List<AdminLeave>> Get()
        {
            List<AdminLeave> AdminLeaves = Repositories.GetAllAdminLeaves();
            if (AdminLeaves.Count > 0)
            {
                return AdminLeaves;
            }
            else
            {
                return NotFound();
            }
        }
        [Route("{id:int}")]
        [HttpGet]
        public ActionResult<AdminLeave> Get(int id)
        {
            AdminLeave adminLeave = Repositories.GetAdminLeaveById(id);
            if (adminLeave != null)
            {
                return adminLeave;
            }
            else
            {
                return NotFound();
            }
        }
        //[Route("{id:int}")]
        [HttpPost]
        public string Post(AdminLeave adminLeave)
        {
            string Response = Repositories.AddNewAdminLeave(adminLeave);
            return Response;
        }
        [HttpPut]
        public string Put(AdminLeave adminLeave)
        {
            string Response = Repositories.UpdateAdminLeave(adminLeave);
            return Response;
        }

        [Route("{id:int}")]
        [HttpDelete]
        public string Delete(int id)
        {
            string Response = Repositories.DeleteAdminLeave(id);
            return Response;
        }
    }
}
