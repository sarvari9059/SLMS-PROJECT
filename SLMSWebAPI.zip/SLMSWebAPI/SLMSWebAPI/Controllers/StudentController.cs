﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SLMSWebAPI.Models;
using SLMSWebAPI.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SLMSWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentRepo2 Repositories = null;
        public StudentController(IStudentRepo2 repo)
        {
            Repositories = repo;
        }
        [HttpGet]
        public ActionResult<List<Student>> Get()
        {
            List<Student> Students = Repositories.GetAllStudents();
            if (Students.Count > 0)
            {
                return Students;
            }
            else
            {
                return NotFound();
            }
        }
        [Route("{id:int}")]
        [HttpGet]
        public ActionResult<Student> Get(int id)
        {
            Student student = Repositories.GetStudentById(id);
            if (student != null)
            {
                return student;
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        public string Post(Student student)
        {
            string Response = Repositories.AddNewStudent(student);
            return Response;
        }
        [HttpPut]
        public string Put(Student student)
        {
            string Response = Repositories.UpdateStudent(student);
            return Response;
        }

        [Route("{id:int}")]
        [HttpDelete]
        public string Delete(int id)
        {
            string Response = Repositories.DeleteStudent(id);
            return Response;
        }
        [HttpGet]
        [Route("{email}/{parentphone}")]
        public async Task<IActionResult> Get(string email,string parentphone)
        {
            Student student = Repositories.StudentGetStudentByName( email, parentphone);
            if (student != null)
            {
                return Ok(student);
            }
            else
            {
                return NotFound("student is invalid");
            }
        }
    }
}
