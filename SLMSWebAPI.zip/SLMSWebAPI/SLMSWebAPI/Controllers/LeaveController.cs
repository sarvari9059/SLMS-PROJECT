﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SLMSWebAPI.Models;
using SLMSWebAPI.Repositories;
using System.Collections.Generic;

namespace SLMSWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LeaveController : ControllerBase
    {
        private readonly ILeaveRepo Repositories = null;
        public LeaveController(ILeaveRepo repo)
        {
            Repositories = repo;
        }
        [HttpGet]
        public ActionResult<List<Leave>> Get()
        {
            List<Leave> Leaves = Repositories.GetAllLeaves();
            if (Leaves.Count > 0)
            {
                return Leaves;
            }
            else
            {
                return NotFound();
            }
        }
        [Route("{id:int}")]
        [HttpGet]
        public ActionResult<Leave> Get(int id)
        {
            Leave leave = Repositories.GetLeaveById(id);
            if (leave != null)
            {
                return leave;
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        public string Post(Leave leave)
        {
            string Response = Repositories.AddNewLeave(leave);
            return Response;
        }
        [HttpPut]
        public string Put(Leave leave)
        {
            string Response = Repositories.UpdateLeave(leave);
            return Response;
        }

        [Route("{id:int}")]
        [HttpDelete]
        public string Delete(int id)
        {
            string Response = Repositories.DeleteLeave(id);
            return Response;
        }
    }
}
