﻿using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using SLMSWebAPI.Models;

namespace SLMSWebAPI.Repositories
{
    public interface ILeaveRepo
    {
        List<Leave> GetAllLeaves();
        string AddNewLeave(Leave leave);
        string UpdateLeave(Leave leave);
        string DeleteLeave(int id);
        Leave GetLeaveById(int id);
    }
}