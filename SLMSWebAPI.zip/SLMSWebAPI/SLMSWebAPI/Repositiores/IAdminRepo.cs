﻿using SLMSWebAPI.Models;
using System.Collections.Generic;

namespace SLMSWebAPI.Repositories
{
    public interface IAdminRepo
    {
        List<Admin> GetAllAdmins();
        string AddNewAdmin(Admin admin);
        string UpdateAdmin(Admin admin);
        string DeletAdmin(int id);
        Admin GetAdminById(int id);
        string DeleteAdmin(int id);
        Admin AdminGetAdminByName(string username,string password);
    }
}
