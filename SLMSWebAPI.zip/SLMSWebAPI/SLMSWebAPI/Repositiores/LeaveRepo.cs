﻿using System.Collections.Generic;
using System.Linq;
using SLMSWebAPI.Models;
using SLMSWebAPI.Repositories;

namespace SLMSWebAPI.Repositories
{
    public class LeaveRepo : ILeaveRepo
    {
        SLMSContext context;
        public LeaveRepo(SLMSContext Context)
        {
            context = Context;
        }
        public string AddNewLeave(Leave leave)
        {
            int count = context.Leaves.Count();

            context.Leaves.Add(leave);
            context.SaveChanges();
            int newCount = context.Leaves.Count();
            if (newCount > count)
            {

                return "record inserted successfully";
            }
            else
            {
                return "oops something went wrong";
            }
        }

        public string DeleteLeave(int id)
        {
            Leave leave = context.Leaves.FirstOrDefault(leave => leave.Id == id);
            if (leave != null)
            {
                context.Leaves.Remove(leave);
                context.SaveChanges();
                return "Leave is deleted";
            }
            else
            {
                return "Leave is not available";
            }

        }

        public List<Leave> GetAllLeaves()
        {
            return context.Leaves.ToList();
        }


        public string UpdateLeave(Leave newleave)
        {
            Leave leave = context.Leaves.FirstOrDefault(leave => leave.Id == newleave.Id);
            if (leave != null)
            {
                leave.Id = newleave.Id;
                leave.StudentId = newleave.StudentId;
                leave.Reason = newleave.Reason;
                leave.Status = newleave.Status;
                leave.Todate = newleave.Todate;
                leave.Fromdate = newleave.Fromdate;
                context.SaveChanges();
                return "Leave details are updated";
            }

            else
            {
                return "Leave details are not updated";
            }

        }

        public Leave GetLeaveById(int id)
        {
            Leave leave = context.Leaves.Find(id);
            return leave;
        }

       
    }
}