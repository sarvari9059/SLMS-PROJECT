﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using SLMSWebAPI.Models;


namespace SLMSWebAPI.Repositories
{
    public class StudentRepo : IStudentRepo2
    {
        readonly SLMSContext context;
        public StudentRepo(SLMSContext Context)
        {
            context = Context;
        }
        public string AddNewStudent(Student student)
        {
            int count = context.Students.Count();
            context.Students.Add(student);
            context.SaveChanges();
            int newCount = context.Students.Count();

            if (newCount > count)
            {

                return "record inserted successfully";
            }
            else
            {
                return "oops something went wrong";
            }


        }

        public string DeleteStudent(int id)
        {
            Student student = context.Students.Find(id);

            if (student != null)
            {
                context.Students.Remove(student);
                context.SaveChanges();
                return "Student is deleted";
            }
            else
            {
                return "Student is not available";
            }

        }

        public List<Student> GetAllStudents()
        {
            return context.Students.ToList();
        }


        public string UpdateStudent(Student newStudent)
        {
            Student s = context.Students.FirstOrDefault(s => s.Id == newStudent.Id);
            if (s != null)
            {
                s.Id = newStudent.Id;
                s.Fullname = newStudent.Fullname;
                s.Email = newStudent.Email;
                s.Parentphone = newStudent.Parentphone;
                context.SaveChanges();
                return "Student details are updated";
            }
            else
            {
                return "Student details are not avaialable";
            }


        }

        public Student GetStudentById(int id)
        {
            Student s = context.Students.Find(id);
            return s;
        }

        public string UpdateEvent(Student s)
        {
            throw new NotImplementedException();
        }
        public Student StudentGetStudentByName(String email, string parentnumber)
        {
           // Student res = null;
            Student student = context.Students.FirstOrDefault(s => s.Email == email &&  s.Parentphone == parentnumber);
            // Student student1 = context.Students.FirstOrDefault(s => s.Parentphone == parentnumber);

            return student;
        }

    }
}