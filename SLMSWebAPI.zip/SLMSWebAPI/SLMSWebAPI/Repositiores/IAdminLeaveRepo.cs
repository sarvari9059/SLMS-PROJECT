﻿using SLMSWebAPI.Models;
using System.Collections.Generic;

namespace SLMSWebAPI.Repositories
{
    public interface IAdminLeaveRepo
    {
        List<AdminLeave> GetAllAdminLeaves();
        string AddNewAdminLeave(AdminLeave a);
        string UpdateAdminLeave(AdminLeave a);
        string DeleteAdminLeave(int id);
        AdminLeave GetAdminLeaveById(int id);
        string DeleteAdminLeave(string id);
    }
}