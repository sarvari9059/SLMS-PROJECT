﻿using SLMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SLMSWebAPI.Repositories
{
    public class AdminRepo : IAdminRepo
    {
        readonly SLMSContext context;

        public AdminRepo(SLMSContext Context)
        {
            context = Context;
        }

        public string AddNewAdmin(Admin admin)
        {
            int count = context.Admins.Count();

            context.Admins.Add(admin);
            context.SaveChanges();
            int newCount = context.Admins.Count();
            if (newCount > count)
            {

                return "record inserted successfully";
            }
            else
            {
                return "oops something went wrong";
            }
        }

        public string DeletAdmin(int id)
        {
            Admin admin = context.Admins.Find(id);
            if (admin != null)
            {
                context.Admins.Remove(admin);
                context.SaveChanges();
                return "Admin is deleted";
            }
            else
            {
                return "admin is not available";
            }
        }
        public List<Admin> GetAllAdmins()
        {
            return context.Admins.ToList();
        }
        public string UpdateAdmin(Admin newAdmin)
        {
            Admin admin = context.Admins.FirstOrDefault(a =>
            a.Id == newAdmin.Id);
            if (admin != null)
            {
                admin.Id = newAdmin.Id;
                admin.Username = newAdmin.Username;
                admin.Password = newAdmin.Password;
                context.SaveChanges();

                return "admin details are updated";

            }
            else
            {
                return "Admin details are not avaialable";
            }
        }
        public Admin GetAdminById(int id, Admin admin)
        {
            Admin admin1 = context.Admins.Find(id);

            return admin;

        }

        public Admin GetAdminById(int id)
        {
            throw new System.NotImplementedException();
        }

        public string DeleteAdmin(int id)
        {
            Admin admin = context.Admins.FirstOrDefault(admin => admin.Id == id);
            if (admin != null)
            {
                context.Admins.Remove(admin);
                context.SaveChanges();
                return "Admin is deleted";
            }
            else
            {
                return "Admin is not available";
            }
        }
        public Admin AdminGetAdminByName(String username, string password)
        {
            Admin res = null;
            Admin admin = context.Admins.FirstOrDefault(a => a.Username == username);
            Admin admin1 = context.Admins.FirstOrDefault(a => a.Password == password);

            if (admin == admin1)
            {
                res = admin;
            }
            return res;
        }
    }
}

