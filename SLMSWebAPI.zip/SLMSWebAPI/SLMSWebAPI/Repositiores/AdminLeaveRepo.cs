﻿using System.Collections.Generic;
using System.Linq;
using System;
using SLMSWebAPI.Models;

namespace SLMSWebAPI.Repositories
{
    public class AdminLeaveRepo : IAdminLeaveRepo
    {
        readonly SLMSContext context;

        public AdminLeaveRepo(SLMSContext AdminLeaveContext)
        {
            context = AdminLeaveContext;
        }
        public string AddNewAdminLeave(AdminLeave adminLeave)
        {
            int count = context.AdminLeaves.Count();

            context.AdminLeaves.Add(adminLeave);
            context.SaveChanges();
            int newAdminLeave = context.AdminLeaves.Count();
            if (newAdminLeave > count)
            {

                return "record inserted successfully";
            }
            else
            {
                return "oops something went wrong";
            }

        }
        public string DeleteAdminLeave(int id)
        {
            AdminLeave adminLeave = context.AdminLeaves.Find(id);
            if (adminLeave != null)
            {
                context.AdminLeaves.Remove(adminLeave);
                context.SaveChanges();
                return "AdminLeave is deleted";

            }
            else
            {
                return "AdminLeave is not available";
            }

        }


        public List<AdminLeave> GetAllAdminLeaves()
        {
            return context.AdminLeaves.ToList();
        }

        public string UpdateAdminLeave(AdminLeave newAdminLeave)
        {
            AdminLeave a = context.AdminLeaves.FirstOrDefault(a => a.Id == newAdminLeave.Id);
            if (a != null)
            {
                a.Id = newAdminLeave.Id;
                a.AdminId = newAdminLeave.AdminId;
                a.LeaveId = newAdminLeave.LeaveId;
                a.Status = newAdminLeave.Status;
                a.AdminRemark = newAdminLeave.AdminRemark;
                context.SaveChanges();
                return "AdminLeave details are updated";


            }
            else
            {
                return "AdminLeave details are not avaialable";
            }

        }
        public AdminLeave GetAdminLeaveById(int id)
        {

            AdminLeave adminLeave = context.AdminLeaves.Find(id);
            return adminLeave;

        }

        public string DeleteAdminLeave(string id)
        {
            throw new NotImplementedException();
        }
    }
}