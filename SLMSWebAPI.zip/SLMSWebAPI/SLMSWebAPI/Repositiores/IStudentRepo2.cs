﻿using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using SLMSWebAPI.Models;

namespace SLMSWebAPI.Repositories
{
    public interface IStudentRepo2
    {
        List<Student> GetAllStudents();
        string AddNewStudent(Student s); 
        string UpdateEvent(Student s); 
        string DeleteStudent(int id);
        Student GetStudentById(int id);
        string UpdateStudent(Student student);
        Student StudentGetStudentByName(string email,string parentphone);
    }
}